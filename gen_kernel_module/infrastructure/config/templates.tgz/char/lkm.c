/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ${LKM}.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/version.h>

#define DRIVER_AUTHOR    "Vladimir Roncevic <elektron.ronca@gmail.com>"
#define DRIVER_DESC      "LKM Character Driver"
#define DRIVER_LICENSE   "GPL"
#define DRIVER_VERSION   "1.0.0"
#define DEVICE_NAME      "${LKM}_cd"
#define CLASS_NAME       "${LKM}"
#define MSG_SIZE         256

struct ${LKM}_device {
	dev_t dev_num;
	struct cdev cdev;
	struct class *class;
	struct device *device;
	struct mutex lock;
	char message[MSG_SIZE];
	size_t size_of_message;
	int number_opens;
};

static struct ${LKM}_device *${LKM}_dev = NULL;

static int ${LKM}_dev_open(struct inode *inodep, struct file *filep)
{
	struct ${LKM}_device *dev = container_of(inodep->i_cdev, struct ${LKM}_device, cdev);
	filep->private_data = dev;

	if (mutex_lock_interruptible(&dev->lock))
		return -ERESTARTSYS;

	dev->number_opens++;
	pr_info("${LKM}_cd: device opened %d time(s)\n", dev->number_opens);
	mutex_unlock(&dev->lock);

	return 0;
}

static int ${LKM}_dev_release(struct inode *inodep, struct file *filep)
{
	pr_info("${LKM}_cd: device closed successfully\n");
	return 0;
}

static ssize_t ${LKM}_dev_read(struct file *filep, char __user *buffer, size_t len, loff_t *offset)
{
	struct ${LKM}_device *dev = filep->private_data;
	size_t bytes_to_read;
	size_t bytes_unread;

	if (mutex_lock_interruptible(&dev->lock))
		return -ERESTARTSYS;

	if (*offset >= dev->size_of_message) {
		mutex_unlock(&dev->lock);
		return 0;
	}

	bytes_to_read = min(len, dev->size_of_message - (size_t)*offset);
	bytes_unread = copy_to_user(buffer, dev->message + *offset, bytes_to_read);

	if (bytes_unread) {
		pr_alert("${LKM}_cd: failed to copy %zu bytes to user\n", bytes_unread);
		mutex_unlock(&dev->lock);
		return -EFAULT;
	}

	*offset += bytes_to_read;
	pr_info("${LKM}_cd: sent %zu bytes to user\n", bytes_to_read);
	mutex_unlock(&dev->lock);

	return bytes_to_read;
}

static ssize_t ${LKM}_dev_write(struct file *filep, const char __user *buffer, size_t len, loff_t *offset)
{
	struct ${LKM}_device *dev = filep->private_data;
	size_t bytes_to_write;
	size_t bytes_unwritten;

	if (mutex_lock_interruptible(&dev->lock))
		return -ERESTARTSYS;

	bytes_to_write = min(len, (size_t)(MSG_SIZE - 1));
	bytes_unwritten = copy_from_user(dev->message, buffer, bytes_to_write);

	if (bytes_unwritten) {
		pr_alert("${LKM}_cd: failed to copy %zu bytes from user\n", bytes_unwritten);
		mutex_unlock(&dev->lock);
		return -EFAULT;
	}

	dev->message[bytes_to_write] = '\0';
	dev->size_of_message = bytes_to_write;
	*offset += bytes_to_write;

	pr_info("${LKM}_cd: received %zu bytes from user: %s\n", bytes_to_write, dev->message);
	mutex_unlock(&dev->lock);

	return bytes_to_write;
}

static const struct file_operations ${LKM}_fops = {
	.owner   = THIS_MODULE,
	.open    = ${LKM}_dev_open,
	.release = ${LKM}_dev_release,
	.read    = ${LKM}_dev_read,
	.write   = ${LKM}_dev_write,
};

static int __init ${LKM}_init(void)
{
	int ret;
	pr_info("${LKM}_cd: initializing character device\n");

	${LKM}_dev = kzalloc(sizeof(*${LKM}_dev), GFP_KERNEL);
	if (!${LKM}_dev)
		return -ENOMEM;

	mutex_init(&${LKM}_dev->lock);

	ret = alloc_chrdev_region(&${LKM}_dev->dev_num, 0, 1, DEVICE_NAME);
	if (ret < 0) {
		pr_alert("${LKM}_cd: failed to allocate major number\n");
		goto err_alloc_chrdev;
	}

	cdev_init(&${LKM}_dev->cdev, &${LKM}_fops);
	${LKM}_dev->cdev.owner = THIS_MODULE;

	ret = cdev_add(&${LKM}_dev->cdev, ${LKM}_dev->dev_num, 1);
	if (ret < 0) {
		pr_alert("${LKM}_cd: failed to add cdev\n");
		goto err_cdev_add;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
	${LKM}_dev->class = class_create(CLASS_NAME);
#else
	${LKM}_dev->class = class_create(THIS_MODULE, CLASS_NAME);
#endif
	if (IS_ERR(${LKM}_dev->class)) {
		pr_alert("${LKM}_cd: failed to create device class\n");
		ret = PTR_ERR(${LKM}_dev->class);
		goto err_class_create;
	}

	${LKM}_dev->device = device_create(
		${LKM}_dev->class, NULL, ${LKM}_dev->dev_num, NULL, DEVICE_NAME
	);
	if (IS_ERR(${LKM}_dev->device)) {
		pr_alert("${LKM}_cd: failed to create device\n");
		ret = PTR_ERR(${LKM}_dev->device);
		goto err_device_create;
	}

	pr_info(
		"${LKM}_cd: device registered correctly with major %d, minor %d\n",
		MAJOR(${LKM}_dev->dev_num), MINOR(${LKM}_dev->dev_num)
	);
	return 0;

err_device_create:
	class_destroy(${LKM}_dev->class);
err_class_create:
	cdev_del(&${LKM}_dev->cdev);
err_cdev_add:
	unregister_chrdev_region(${LKM}_dev->dev_num, 1);
err_alloc_chrdev:
	mutex_destroy(&${LKM}_dev->lock);
	kfree(${LKM}_dev);
	return ret;
}

static void __exit ${LKM}_exit(void)
{
	device_destroy(${LKM}_dev->class, ${LKM}_dev->dev_num);
	class_destroy(${LKM}_dev->class);
	cdev_del(&${LKM}_dev->cdev);
	unregister_chrdev_region(${LKM}_dev->dev_num, 1);
	mutex_destroy(&${LKM}_dev->lock);
	kfree(${LKM}_dev);
	pr_info("${LKM}_cd: module successfully unloaded\n");
}

module_init(${LKM}_init);
module_exit(${LKM}_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);
MODULE_VERSION(DRIVER_VERSION);
