/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#define BUFFER_LENGTH 256
static char receive[BUFFER_LENGTH];

int main(void)
{
	int ret, fd;
	char string_to_send[BUFFER_LENGTH];

	printf("Starting ${LKM} device test...\n");
	fd = open("/dev/${LKM}_cd", O_RDWR);

	if (fd < 0) {
		perror("Failed to open the device /dev/${LKM}_cd");
		return errno;
	}

	printf("Type in a short string to send to the kernel module:\n");
	if (scanf("%255[^\n]%*c", string_to_send) != 1) {
		strncpy(string_to_send, "Hello from userspace", sizeof(string_to_send) - 1);
	}

	printf("Writing message to the device [%s]...\n", string_to_send);
	ret = write(fd, string_to_send, strlen(string_to_send));
	if (ret < 0) {
		perror("Failed to write the message to the device");
		close(fd);
		return errno;
	}

	printf("Reading from the device...\n");
	ret = read(fd, receive, BUFFER_LENGTH - 1);
	if (ret < 0) {
		perror("Failed to read the message from the device");
		close(fd);
		return errno;
	}
	receive[ret] = '\0';

	printf("The received message is: [%s]\n", receive);
	close(fd);
	printf("End of the program\n");

	return 0;
}
