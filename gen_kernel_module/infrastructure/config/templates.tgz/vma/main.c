/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

#define PAGE_SIZE 4096

int main(void)
{
	int fd;
	char *map;
	const char *dev_path = "/dev/${LKM}_vma";

	printf("Starting ${LKM} VMA mmap test...\n");
	fd = open(dev_path, O_RDWR);
	if (fd < 0) {
		perror("Failed to open VMA device");
		return errno;
	}

	map = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (map == MAP_FAILED) {
		perror("mmap failed");
		close(fd);
		return errno;
	}

	printf("Read from kernel mmap buffer: %s\n", map);
	snprintf(map, PAGE_SIZE, "Userspace was here!\n");
	printf("Updated kernel mmap buffer content.\n");

	if (munmap(map, PAGE_SIZE) < 0) {
		perror("munmap failed");
	}

	close(fd);
	printf("VMA test completed successfully.\n");
	return 0;
}
