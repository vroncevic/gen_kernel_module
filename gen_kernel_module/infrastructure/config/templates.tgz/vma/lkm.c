/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ${LKM}.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/mm.h>
#include <linux/io.h>
#include <linux/slab.h>
#include <linux/version.h>

#define DRIVER_AUTHOR    "Vladimir Roncevic <elektron.ronca@gmail.com>"
#define DRIVER_DESC      "LKM Virtual Memory Addressing Driver"
#define DRIVER_LICENSE   "GPL"
#define DRIVER_VERSION   "1.0.0"
#define DEVICE_NAME      "${LKM}_vma"
#define CLASS_NAME       "${LKM}"
#define VMA_BUFFER_SIZE  PAGE_SIZE

struct ${LKM}_vma_dev {
	dev_t dev_num;
	struct cdev cdev;
	struct class *class;
	struct device *device;
	char *buffer;
};

static struct ${LKM}_vma_dev *${LKM}_vdev = NULL;

static void ${LKM}_vma_open(struct vm_area_struct *vma)
{
	pr_info("${LKM}_vma: VMA opened, virt 0x%lx\n", vma->vm_start);
}

static void ${LKM}_vma_close(struct vm_area_struct *vma)
{
	pr_info("${LKM}_vma: VMA closed\n");
}

static const struct vm_operations_struct ${LKM}_vm_ops = {
	.open  = ${LKM}_vma_open,
	.close = ${LKM}_vma_close,
};

static int ${LKM}_mmap(struct file *filep, struct vm_area_struct *vma)
{
	struct ${LKM}_vma_dev *dev = filep->private_data;
	unsigned long pfn;
	unsigned long length = vma->vm_end - vma->vm_start;

	if (length > VMA_BUFFER_SIZE)
		return -EINVAL;

	pfn = virt_to_phys((void *)dev->buffer) >> PAGE_SHIFT;

	if (remap_pfn_range(vma, vma->vm_start, pfn, length, vma->vm_page_prot)) {
		pr_alert("${LKM}_vma: remap_pfn_range failed\n");
		return -EAGAIN;
	}

	vma->vm_ops = &${LKM}_vm_ops;
	${LKM}_vma_open(vma);
	return 0;
}

static int ${LKM}_open(struct inode *inodep, struct file *filep)
{
	struct ${LKM}_vma_dev *dev = container_of(inodep->i_cdev, struct ${LKM}_vma_dev, cdev);
	filep->private_data = dev;
	pr_info("${LKM}_vma: device opened\n");
	return 0;
}

static int ${LKM}_release(struct inode *inodep, struct file *filep)
{
	pr_info("${LKM}_vma: device closed\n");
	return 0;
}

static const struct file_operations ${LKM}_fops = {
	.owner   = THIS_MODULE,
	.open    = ${LKM}_open,
	.release = ${LKM}_release,
	.mmap    = ${LKM}_mmap,
};

static int __init ${LKM}_init(void)
{
	int ret;
	pr_info("${LKM}_vma: initializing VMA character device\n");

	${LKM}_vdev = kzalloc(sizeof(*${LKM}_vdev), GFP_KERNEL);
	if (!${LKM}_vdev)
		return -ENOMEM;

	${LKM}_vdev->buffer = (char *)__get_free_page(GFP_KERNEL);
	if (!${LKM}_vdev->buffer) {
		ret = -ENOMEM;
		goto err_alloc_buf;
	}
	snprintf(${LKM}_vdev->buffer, PAGE_SIZE, "Hello from ${LKM} VMA kernel memory!\n");

	ret = alloc_chrdev_region(&${LKM}_vdev->dev_num, 0, 1, DEVICE_NAME);
	if (ret < 0) {
		pr_alert("${LKM}_vma: failed to allocate chrdev region\n");
		goto err_alloc_chrdev;
	}

	cdev_init(&${LKM}_vdev->cdev, &${LKM}_fops);
	${LKM}_vdev->cdev.owner = THIS_MODULE;

	ret = cdev_add(&${LKM}_vdev->cdev, ${LKM}_vdev->dev_num, 1);
	if (ret < 0) {
		pr_alert("${LKM}_vma: failed to add cdev\n");
		goto err_cdev_add;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
	${LKM}_vdev->class = class_create(CLASS_NAME);
#else
	${LKM}_vdev->class = class_create(THIS_MODULE, CLASS_NAME);
#endif
	if (IS_ERR(${LKM}_vdev->class)) {
		pr_alert("${LKM}_vma: failed to create device class\n");
		ret = PTR_ERR(${LKM}_vdev->class);
		goto err_class_create;
	}

	${LKM}_vdev->device = device_create(
		${LKM}_vdev->class, NULL, ${LKM}_vdev->dev_num, NULL, DEVICE_NAME
	);
	if (IS_ERR(${LKM}_vdev->device)) {
		pr_alert("${LKM}_vma: failed to create device\n");
		ret = PTR_ERR(${LKM}_vdev->device);
		goto err_device_create;
	}

	pr_info(
		"${LKM}_vma: registered correctly with major %d, minor %d\n",
		MAJOR(${LKM}_vdev->dev_num), MINOR(${LKM}_vdev->dev_num)
	);
	return 0;

err_device_create:
	class_destroy(${LKM}_vdev->class);
err_class_create:
	cdev_del(&${LKM}_vdev->cdev);
err_cdev_add:
	unregister_chrdev_region(${LKM}_vdev->dev_num, 1);
err_alloc_chrdev:
	free_page((unsigned long)${LKM}_vdev->buffer);
err_alloc_buf:
	kfree(${LKM}_vdev);
	return ret;
}

static void __exit ${LKM}_exit(void)
{
	device_destroy(${LKM}_vdev->class, ${LKM}_vdev->dev_num);
	class_destroy(${LKM}_vdev->class);
	cdev_del(&${LKM}_vdev->cdev);
	unregister_chrdev_region(${LKM}_vdev->dev_num, 1);
	free_page((unsigned long)${LKM}_vdev->buffer);
	kfree(${LKM}_vdev);
	pr_info("${LKM}_vma: VMA driver successfully unloaded\n");
}

module_init(${LKM}_init);
module_exit(${LKM}_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);
MODULE_VERSION(DRIVER_VERSION);
