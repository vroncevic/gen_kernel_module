/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#define SECTOR_SIZE 512

int main(void)
{
	int fd;
	char buffer[SECTOR_SIZE];
	const char *dev_path = "/dev/${LKM}_bd0";

	printf("Starting ${LKM} block device test...\n");
	fd = open(dev_path, O_RDWR);
	if (fd < 0) {
		perror("Failed to open block device");
		printf("Note: Ensure the module is loaded and run with appropriate permissions.\n");
		return errno;
	}

	memset(buffer, 0xAB, SECTOR_SIZE);
	if (write(fd, buffer, SECTOR_SIZE) != SECTOR_SIZE) {
		perror("Failed to write sector");
		close(fd);
		return errno;
	}
	printf("Successfully wrote sector to %s\n", dev_path);

	lseek(fd, 0, SEEK_SET);
	memset(buffer, 0, SECTOR_SIZE);
	if (read(fd, buffer, SECTOR_SIZE) != SECTOR_SIZE) {
		perror("Failed to read sector");
		close(fd);
		return errno;
	}
	printf("Successfully read sector from %s (first byte: 0x%02X)\n", dev_path, (unsigned char)buffer[0]);

	close(fd);
	printf("Block device test completed successfully.\n");
	return 0;
}
