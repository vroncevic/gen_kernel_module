/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ${LKM}.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/vmalloc.h>
#include <linux/blkdev.h>
#include <linux/spinlock.h>
#include <linux/highmem.h>
#include <linux/slab.h>
#include <linux/version.h>

#define DRIVER_AUTHOR    "Vladimir Roncevic <elektron.ronca@gmail.com>"
#define DRIVER_DESC      "LKM Modern Block Driver"
#define DRIVER_LICENSE   "GPL"
#define DRIVER_VERSION   "1.0.0"
#define DEVICE_NAME      "${LKM}_bd"

#ifndef SECTOR_SIZE
#define SECTOR_SIZE         512
#endif
#define DEFAULT_NSECTORS    2048

static int nsectors = DEFAULT_NSECTORS;
module_param(nsectors, int, 0644);
MODULE_PARM_DESC(nsectors, "Number of 512-byte sectors for the virtual disk");

struct ${LKM}_block_device {
	int major;
	struct gendisk *disk;
	u8 *data;
	size_t size;
	spinlock_t lock;
};

static struct ${LKM}_block_device *${LKM}_bdev = NULL;

static void ${LKM}_submit_bio(struct bio *bio)
{
	struct ${LKM}_block_device *dev = bio->bi_bdev->bd_disk->private_data;
	struct bio_vec bvec;
	struct bvec_iter iter;
	sector_t sector = bio->bi_iter.bi_sector;
	loff_t pos = sector << 9;

	bio_for_each_segment(bvec, bio, iter) {
		unsigned int len = bvec.bv_len;
		void *buffer;

		if (pos + len > dev->size) {
			bio_io_error(bio);
			return;
		}

		buffer = kmap_local_page(bvec.bv_page) + bvec.bv_offset;

		if (bio_data_dir(bio) == WRITE)
			memcpy(dev->data + pos, buffer, len);
		else
			memcpy(buffer, dev->data + pos, len);

		kunmap_local(buffer);
		pos += len;
	}

	bio_endio(bio);
}

static int ${LKM}_open(struct gendisk *disk, blk_mode_t mode)
{
	pr_info("${LKM}_bd: block device opened\n");
	return 0;
}

static void ${LKM}_release(struct gendisk *disk)
{
	pr_info("${LKM}_bd: block device released\n");
}

static const struct block_device_operations ${LKM}_fops = {
	.owner      = THIS_MODULE,
	.open       = ${LKM}_open,
	.release    = ${LKM}_release,
	.submit_bio = ${LKM}_submit_bio,
};

static int __init ${LKM}_init(void)
{
	int ret;
	pr_info("${LKM}_bd: initializing block device\n");

	${LKM}_bdev = kzalloc(sizeof(*${LKM}_bdev), GFP_KERNEL);
	if (!${LKM}_bdev)
		return -ENOMEM;

	spin_lock_init(&${LKM}_bdev->lock);
	${LKM}_bdev->size = (size_t)nsectors * SECTOR_SIZE;
	${LKM}_bdev->data = vmalloc(${LKM}_bdev->size);
	if (!${LKM}_bdev->data) {
		ret = -ENOMEM;
		goto err_alloc_data;
	}
	memset(${LKM}_bdev->data, 0, ${LKM}_bdev->size);

	${LKM}_bdev->major = register_blkdev(0, DEVICE_NAME);
	if (${LKM}_bdev->major < 0) {
		pr_alert("${LKM}_bd: unable to register blkdev\n");
		ret = ${LKM}_bdev->major;
		goto err_register_blkdev;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 9, 0)
	${LKM}_bdev->disk = blk_alloc_disk(NULL, NUMA_NO_NODE);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0)
	${LKM}_bdev->disk = blk_alloc_disk(NUMA_NO_NODE);
#else
	#error "Modern block driver requires Linux 5.14 or newer"
#endif

	if (IS_ERR_OR_NULL(${LKM}_bdev->disk)) {
		pr_alert("${LKM}_bd: failed to allocate disk structure\n");
		ret = ${LKM}_bdev->disk ? PTR_ERR(${LKM}_bdev->disk) : -ENOMEM;
		goto err_alloc_disk;
	}

	${LKM}_bdev->disk->major = ${LKM}_bdev->major;
	${LKM}_bdev->disk->first_minor = 0;
	${LKM}_bdev->disk->minors = 1;
	${LKM}_bdev->disk->fops = &${LKM}_fops;
	${LKM}_bdev->disk->private_data = ${LKM}_bdev;
	snprintf(${LKM}_bdev->disk->disk_name, sizeof(${LKM}_bdev->disk->disk_name), "${LKM}_bd0");
	set_capacity(${LKM}_bdev->disk, nsectors);

	ret = add_disk(${LKM}_bdev->disk);
	if (ret) {
		pr_alert("${LKM}_bd: add_disk failed\n");
		goto err_add_disk;
	}

	pr_info(
		"${LKM}_bd: disk %s successfully registered (%d sectors, %zu bytes)\n",
		${LKM}_bdev->disk->disk_name, nsectors, ${LKM}_bdev->size
	);
	return 0;

err_add_disk:
	put_disk(${LKM}_bdev->disk);
err_alloc_disk:
	unregister_blkdev(${LKM}_bdev->major, DEVICE_NAME);
err_register_blkdev:
	vfree(${LKM}_bdev->data);
err_alloc_data:
	kfree(${LKM}_bdev);
	return ret;
}

static void __exit ${LKM}_exit(void)
{
	del_gendisk(${LKM}_bdev->disk);
	put_disk(${LKM}_bdev->disk);
	unregister_blkdev(${LKM}_bdev->major, DEVICE_NAME);
	vfree(${LKM}_bdev->data);
	kfree(${LKM}_bdev);
	pr_info("${LKM}_bd: block driver successfully unloaded\n");
}

module_init(${LKM}_init);
module_exit(${LKM}_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);
MODULE_VERSION(DRIVER_VERSION);
