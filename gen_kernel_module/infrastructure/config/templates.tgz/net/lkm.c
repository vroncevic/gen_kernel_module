/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ${LKM}.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/skbuff.h>

#define DRIVER_AUTHOR    "Vladimir Roncevic <elektron.ronca@gmail.com>"
#define DRIVER_DESC      "LKM Virtual Network Interface"
#define DRIVER_LICENSE   "GPL"
#define DRIVER_VERSION   "1.0.0"

struct ${LKM}_net_priv {
	struct net_device *netdev;
	struct net_device_stats stats;
};

static int ${LKM}_open(struct net_device *dev)
{
	netif_start_queue(dev);
	pr_info("${LKM}: network interface %s opened\n", dev->name);
	return 0;
}

static int ${LKM}_stop(struct net_device *dev)
{
	netif_stop_queue(dev);
	pr_info("${LKM}: network interface %s stopped\n", dev->name);
	return 0;
}

static netdev_tx_t ${LKM}_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
	struct ${LKM}_net_priv *priv = netdev_priv(dev);

	priv->stats.tx_packets++;
	priv->stats.tx_bytes += skb->len;

	dev_kfree_skb(skb);
	return NETDEV_TX_OK;
}

static struct net_device_stats *${LKM}_get_stats(struct net_device *dev)
{
	struct ${LKM}_net_priv *priv = netdev_priv(dev);
	return &priv->stats;
}

static const struct net_device_ops ${LKM}_netdev_ops = {
	.ndo_open       = ${LKM}_open,
	.ndo_stop       = ${LKM}_stop,
	.ndo_start_xmit = ${LKM}_start_xmit,
	.ndo_get_stats  = ${LKM}_get_stats,
};

static void ${LKM}_setup(struct net_device *dev)
{
	ether_setup(dev);
	dev->netdev_ops = &${LKM}_netdev_ops;
	dev->flags |= IFF_NOARP;
	eth_hw_addr_random(dev);
}

static struct net_device *${LKM}_dev = NULL;

static int __init ${LKM}_init(void)
{
	int ret;
	pr_info("${LKM}: initializing network interface\n");

	${LKM}_dev = alloc_netdev(
		sizeof(struct ${LKM}_net_priv),
		"${LKM}%d",
		NET_NAME_UNKNOWN,
		${LKM}_setup
	);

	if (!${LKM}_dev) {
		pr_alert("${LKM}: failed to allocate net_device\n");
		return -ENOMEM;
	}

	ret = register_netdev(${LKM}_dev);
	if (ret) {
		pr_alert("${LKM}: failed to register network device (%d)\n", ret);
		free_netdev(${LKM}_dev);
		return ret;
	}

	pr_info("${LKM}: registered network interface %s\n", ${LKM}_dev->name);
	return 0;
}

static void __exit ${LKM}_exit(void)
{
	unregister_netdev(${LKM}_dev);
	free_netdev(${LKM}_dev);
	pr_info("${LKM}: unregistered network interface\n");
}

module_init(${LKM}_init);
module_exit(${LKM}_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);
MODULE_VERSION(DRIVER_VERSION);
