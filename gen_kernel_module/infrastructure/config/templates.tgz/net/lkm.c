/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ${LKM}.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * 
 * ${LKM} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ${LKM} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/uaccess.h>
#include <linux/fs.h>

#define    DRIVER_AUTHOR    "Vladimir Roncevic <elektron.ronca@gmail.com>"
#define    DRIVER_DESC      "LKM Network Interface"
#define    DRIVER_LICENSE   "GPL"
#define    DRIVER_VERSION   "1.0.0"
#define    DEVICE_NAME      "${LKM}_ni"
#define    CLASS_NAME       "${LKM}"
#define    MSG_SIZE         256

static int major_number;
static char message[MSG_SIZE] = {0};
static short size_of_message;
static int number_opens = 0;
static struct class* ${LKM}CharClass = NULL;
static struct device* ${LKM}CharDevice = NULL;

static int dev_open(struct inode*, struct file*);
static int dev_release(struct inode*, struct file*);
static ssize_t dev_read(struct file*, char*, size_t, loff_t*);
static ssize_t dev_write(struct file*, const char*, size_t, loff_t*);

static struct file_operations fops =
{
    .open = dev_open,
    .read = dev_read,
    .write = dev_write,
    .release = dev_release,
};

static int __init ${LKM}_init(void)
{
    printk(KERN_INFO "${LKM}_ni: Initializing the ${LKM}_ni LKM\n");
    /* TODO */
    printk(KERN_INFO "${LKM}_ni: device class created correctly\n");

    return 0;
}

static void __exit ${LKM}_exit(void)
{
    device_destroy(${LKM}CharClass, MKDEV(major_number, 0));
    class_unregister(${LKM}CharClass);
    class_destroy(${LKM}CharClass);
    unregister_chrdev(major_number, DEVICE_NAME);
    printk(KERN_INFO "${LKM}_ni: goodbye from the LKM!\n");
}

static int dev_open(struct inode *inodep, struct file *filep)
{
    number_opens++;

    printk(
        KERN_INFO "${LKM}_ni: device has been opened %d time(s)\n",
        number_opens
    );

    return 0;
}

static ssize_t dev_read(
    struct file *filep, char *buffer, size_t len, loff_t *offset
)
{
    int error_count = 0;
    error_count = copy_to_user(buffer, message, size_of_message);

    if(error_count==0)
    {
        printk(
            KERN_INFO "${LKM}_ni: sent %d bytes to the user\n",
            size_of_message
        );

        return (size_of_message=0);
    }
    else
    {
        printk(
            KERN_INFO "${LKM}_ni: failed to send %d bytes to the user\n",
            error_count
        );

        return -EFAULT;
    }
}

static ssize_t dev_write(
    struct file *filep, const char *buffer, size_t len, loff_t *offset
)
{
    sprintf(message, "%s(%zu letters)", buffer, len);
    size_of_message = strlen(message);

    printk(
        KERN_INFO "${LKM}_ni: received %zu bytes from the user\n", len
    );

    return len;
}

static int dev_release(struct inode *inodep, struct file *filep)
{
    printk(KERN_INFO "${LKM}_ni: device successfully closed\n");

    return 0;
}

module_init(${LKM}_init);
module_exit(${LKM}_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);
MODULE_VERSION(DRIVER_VERSION);

